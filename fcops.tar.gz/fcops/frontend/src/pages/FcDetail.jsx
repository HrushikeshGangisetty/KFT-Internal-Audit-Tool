import { useCallback, useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api, listOf } from '../lib/api'
import { useAuth } from '../lib/auth.jsx'
import {
  Banner, Empty, Field, IssueLink, Loading, SeverityTag, StatusTag, Tag, humanize, when,
} from '../components/ui.jsx'

const TEST_STAGES = ['SENSOR_VALIDATION', 'BENCH_TESTING', 'GROUND_TESTING', 'FINAL_VALIDATION']

export default function FcDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const [fc, setFc] = useState(null)
  const [tab, setTab] = useState('timeline')
  const [timeline, setTimeline] = useState([])
  const [records, setRecords] = useState([])
  const [issues, setIssues] = useState([])
  const [auditRows, setAuditRows] = useState([])
  const [meta, setMeta] = useState({ stages: [], rework_targets: {} })
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [notes, setNotes] = useState('')
  const [failing, setFailing] = useState(false)
  const [busy, setBusy] = useState(false)

  // One request instead of four. Over a link to a distant database the round
  // trips dominate, so the page loads in a quarter of the time.
  const reload = useCallback(async () => {
    const data = await api(`/api/fcs/${id}/full/`)
    setFc(data.fc)
    setTimeline(data.timeline)
    setRecords(data.stage_records)
    setIssues(data.issues)
  }, [id])

  useEffect(() => {
    api('/api/lifecycle/').then(setMeta).catch(() => {})
    reload().catch((e) => setError(e.message))
  }, [reload])

  useEffect(() => {
    if (tab === 'audit' && auditRows.length === 0) {
      api(`/api/fcs/${id}/audit_log/`).then(setAuditRows).catch(() => {})
    }
  }, [tab, id, auditRows.length])

  const act = async (path, body = {}) => {
    setBusy(true); setError(''); setMessage('')
    try {
      await api(`/api/fcs/${id}/${path}/`, { method: 'POST', body: { notes, ...body } })
      setNotes('')
      await reload()
      setMessage('Done.')
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  if (error && !fc) return <Banner>{error}</Banner>
  if (!fc) return <Loading what="FC" />

  const current = records.filter((r) => r.stage === fc.current_stage)
    .sort((a, b) => b.attempt - a.attempt)[0]
  const canApprove = user?.permissions?.can_approve
  const terminal = fc.status === 'APPROVED' || fc.status === 'REJECTED'

  return (
    <>
      <div className="row" style={{ marginBottom: 12 }}>
        <h2 className="mono" style={{ margin: 0, fontSize: 20 }}>{fc.serial}</h2>
        <StatusTag value={fc.status} />
        <Tag>{fc.fc_model_name}</Tag>
        {fc.hardware_revision ? <Tag>{fc.hardware_revision}</Tag> : null}
        <div style={{ flex: 1 }} />
        <Link className="btn" style={{ color: '#fff', padding: '8px 14px' }}
              to={`/issues/new?fc=${fc.id}&stage=${fc.current_stage}`}>
          Report an issue
        </Link>
      </div>

      <Banner>{error}</Banner>
      <Banner kind="ok">{message}</Banner>

      <div className="card">
        <h2>Lifecycle progress</h2>
        <div className="stage-strip">
          {fc.stage_progress.map((s) => (
            <div key={s.stage}
                 className={`stage-chip ${s.status.toLowerCase()} ${s.stage === fc.current_stage ? 'current' : ''}`}>
              <span>{s.status === 'PASSED' ? '✓' : s.status === 'FAILED' ? '✕' : s.status === 'IN_PROGRESS' ? '◐' : '○'}</span>
              <span>{s.label}</span>
              {s.attempts > 1 ? <span className="muted">×{s.attempts}</span> : null}
            </div>
          ))}
        </div>
      </div>

      <div className="split">
        <div>
          <div className="card">
            <div className="row" style={{ marginBottom: 10 }}>
              {['timeline', 'stages', 'issues', 'firmware', 'test', 'audit'].map((t) => (
                <button key={t} className={tab === t ? '' : 'secondary'}
                        onClick={() => setTab(t)}>
                  {humanize(t)}
                </button>
              ))}
            </div>

            {tab === 'timeline' ? <Timeline events={timeline} /> : null}
            {tab === 'stages' ? <StageRecords records={records} fc={fc} meta={meta} onDone={reload} /> : null}
            {tab === 'issues' ? <IssuesTable issues={issues} /> : null}
            {tab === 'firmware' ? <FirmwareTab fc={fc} current={current} onDone={reload} /> : null}
            {tab === 'test' ? <TestTab fc={fc} current={current} onDone={reload} /> : null}
            {tab === 'audit' ? <AuditTable rows={auditRows} /> : null}
          </div>
        </div>

        <div>
          <div className="card">
            <h2>Current stage</h2>
            <p style={{ marginTop: 0 }}>
              <strong>{humanize(fc.current_stage)}</strong>{' '}
              {current ? <StatusTag value={current.status} /> : null}
              {current?.attempt > 1 ? <span className="muted small"> attempt {current.attempt}</span> : null}
            </p>
            {terminal ? (
              <p className="muted small">This FC is {humanize(fc.status).toLowerCase()}; no further stage actions.</p>
            ) : (
              <>
                <Field label="Notes for this action">
                  <textarea value={notes} onChange={(e) => setNotes(e.target.value)}
                            placeholder="Optional — what was observed, who signed off…" />
                </Field>
                {fc.stage_blockers?.length ? (
                  <div className="banner warn">
                    <strong>This stage cannot pass yet.</strong>
                    <ul style={{ margin: '6px 0 0', paddingLeft: 18 }}>
                      {fc.stage_blockers.map((reason, i) => <li key={i}>{reason}</li>)}
                    </ul>
                  </div>
                ) : null}
                {fc.current_stage === 'MANAGER_APPROVAL' ? (
                  <ApprovalPanel fc={fc} canApprove={canApprove} busy={busy} act={act} />
                ) : (
                  <>
                    <div className="row">
                      <button className="secondary" disabled={busy}
                              onClick={() => act('start_stage')}>Start stage</button>
                      <button className="ok" disabled={busy || fc.stage_blockers?.length > 0}
                              title={fc.stage_blockers?.length
                                ? 'Resolve and verify the open issues first'
                                : ''}
                              onClick={() => act('pass_stage')}>Mark passed</button>
                      <button className="danger" disabled={busy}
                              onClick={() => setFailing((v) => !v)}>
                        {failing ? 'Cancel' : 'Mark failed'}
                      </button>
                    </div>
                    {failing ? (
                      <FailPanel fc={fc} busy={busy} notes={notes}
                                 onSubmit={(body) => {
                                   setFailing(false)
                                   return act('fail_stage', body)
                                 }} />
                    ) : null}
                  </>
                )}
              </>
            )}
            {fc.approval_blockers.blockers.length ? (
              <div style={{ marginTop: 12 }}>
                <h3>Blocking release</h3>
                <ul className="small" style={{ paddingLeft: 18, margin: 0 }}>
                  {fc.approval_blockers.blockers.slice(0, 6).map((b, i) => <li key={i}>{b}</li>)}
                </ul>
              </div>
            ) : null}
          </div>

          <div className="card">
            <h2>Record</h2>
            <dl className="kv">
              <dt>Model</dt><dd>{fc.fc_model_name}</dd>
              <dt>Revision</dt><dd>{fc.hardware_revision || '—'}</dd>
              <dt>PCB batch</dt><dd>{fc.pcb_batch || '—'}</dd>
              <dt>Firmware</dt>
              <dd>{fc.current_firmware
                ? `${fc.current_firmware.firmware_name} ${fc.current_firmware.version}`
                : '—'}</dd>
              <dt>Registered</dt><dd>{when(fc.created_at)} by {fc.registered_by_name || '—'}</dd>
              {fc.approved_at ? (<><dt>Decision</dt>
                <dd>{when(fc.approved_at)} by {fc.approved_by_name}</dd></>) : null}
            </dl>
            {fc.notes ? <p className="small muted" style={{ marginBottom: 0 }}>{fc.notes}</p> : null}
          </div>
        </div>
      </div>
    </>
  )
}

function ApprovalPanel({ fc, canApprove, busy, act }) {
  const [justification, setJustification] = useState('')
  if (!canApprove) {
    return <p className="muted small">Only a manager or admin can record the final release decision.</p>
  }
  return (
    <>
      {fc.approval_blockers.warnings.length ? (
        <>
          <div className="banner warn">
            Unverified non-blocking issues remain. A justification is mandatory.
          </div>
          <Field label="Deviation justification">
            <textarea value={justification} onChange={(e) => setJustification(e.target.value)} />
          </Field>
        </>
      ) : null}
      <div className="row">
        <button className="ok" disabled={busy}
                onClick={() => act('approve', { approve: true, deviation_justification: justification })}>
          Approve for release
        </button>
        <button className="danger" disabled={busy}
                onClick={() => act('approve', { approve: false, note: justification })}>
          Reject / scrap
        </button>
      </div>
    </>
  )
}

function Timeline({ events }) {
  if (!events.length) return <Empty>No events yet.</Empty>
  return (
    <ul className="timeline">
      {events.map((e) => (
        <li key={e.id} className={e.kind.includes('FAIL') || e.kind.includes('OPENED') ? 'bad'
          : e.kind.includes('PASS') || e.kind.includes('VERIFIED') || e.kind.includes('APPROVED') ? 'ok' : ''}>
          <div className="t">{e.title}</div>
          {e.detail ? <div className="small">{e.detail}</div> : null}
          <div className="meta">
            {when(e.created_at)} · {e.actor_name || 'system'}
            {e.stage_label ? ` · ${e.stage_label}` : ''}
            {e.issue ? <> · <IssueLink id={e.issue} label={e.issue_key} /></> : null}
          </div>
        </li>
      ))}
    </ul>
  )
}

function StageRecords({ records, fc, meta, onDone }) {
  const [reworkFor, setReworkFor] = useState(null)
  if (!records.length) return <Empty />
  return (
    <>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Stage</th><th>Attempt</th><th>Status</th><th>Operator</th>
              <th>Completed</th><th>Notes</th><th /></tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r.id}>
                <td>{r.stage_label}</td>
                <td>{r.attempt}</td>
                <td><StatusTag value={r.status} /></td>
                <td className="small">{r.operator_name || '—'}</td>
                <td className="small muted">{when(r.completed_at)}</td>
                <td className="small">{r.notes || '—'}</td>
                <td>
                  {r.status === 'FAILED' && r.allowed_rework_targets.length ? (
                    <button className="link" onClick={() => setReworkFor(r)}>Add rework</button>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {reworkFor ? (
        <ReworkForm record={reworkFor} fc={fc} onClose={() => setReworkFor(null)}
                    onDone={() => { setReworkFor(null); onDone() }} />
      ) : null}
    </>
  )
}

function ReworkForm({ record, fc, onClose, onDone }) {
  const [description, setDescription] = useState('')
  const [target, setTarget] = useState(record.allowed_rework_targets[0]?.value || '')
  const [issue, setIssue] = useState('')
  const [issues, setIssues] = useState([])
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    api(`/api/fcs/${fc.id}/issues/`).then(setIssues).catch(() => {})
  }, [fc.id])

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true); setError('')
    try {
      const rework = await api('/api/rework-records/', {
        method: 'POST',
        body: {
          stage_record: record.id, description, return_to_stage: target,
          originating_issue: issue ? Number(issue) : null,
        },
      })
      await api(`/api/rework-records/${rework.id}/complete/`, {
        method: 'POST', body: { outcome: 'COMPLETED', outcome_notes: description },
      })
      onDone()
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit} style={{ marginTop: 14, borderTop: '1px solid var(--border)', paddingTop: 14 }}>
      <h3>Rework on {record.stage_label} (attempt {record.attempt})</h3>
      <Banner>{error}</Banner>
      <Field label="What was reworked">
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} required />
      </Field>
      <Field label="Return the FC to" hint="Only routes allowed for this failure are listed.">
        <select value={target} onChange={(e) => setTarget(e.target.value)}>
          {record.allowed_rework_targets.map((t) => (
            <option key={t.value} value={t.value}>{t.label}</option>
          ))}
        </select>
      </Field>
      <Field label="Originating issue">
        <select value={issue} onChange={(e) => setIssue(e.target.value)}>
          <option value="">— none —</option>
          {issues.map((i) => <option key={i.id} value={i.id}>{i.key} · {i.title}</option>)}
        </select>
      </Field>
      <div className="row">
        <button disabled={busy || !description}>Record rework &amp; return FC</button>
        <button type="button" className="secondary" onClick={onClose}>Cancel</button>
      </div>
    </form>
  )
}

function IssuesTable({ issues }) {
  if (!issues.length) return <Empty>No issues raised against this FC.</Empty>
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Key</th><th>Title</th><th>Discovered at</th><th>Assigned to</th>
          <th>Severity</th><th>Status</th></tr></thead>
        <tbody>
          {issues.map((i) => (
            <tr key={i.id}>
              <td><IssueLink id={i.id} label={i.key} /></td>
              <td>{i.title}</td>
              <td className="small">{i.stage_label}<br />
                <span className="muted">{i.discovering_department_name}</span></td>
              <td className="small">{i.assigned_department_name || '—'}</td>
              <td><SeverityTag value={i.severity} /></td>
              <td><StatusTag value={i.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function FirmwareTab({ fc, current, onDone }) {
  const [rows, setRows] = useState([])
  const [profiles, setProfiles] = useState([])
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [form, setForm] = useState({
    firmware_name: '', version: '', source_type: 'OPEN_SOURCE', is_signed: false,
    is_locked: false, bootloader_version: '', build_ref: '', parameter_profile: '',
    script_name: '', script_version: '', flashing_result: 'SUCCESS',
    config_result: 'SUCCESS', notes: '',
  })

  const [builds, setBuilds] = useState([])
  const [selectedBuild, setSelectedBuild] = useState('')
  const [flashNotes, setFlashNotes] = useState('')
  const [flashResult, setFlashResult] = useState('SUCCESS')
  const [manual, setManual] = useState(false)

  const load = useCallback(() => {
    api('/api/firmware-records/', { params: { fc: fc.id } }).then((d) => setRows(listOf(d)))
    api('/api/parameter-profiles/').then((d) => setProfiles(listOf(d)))
    api('/api/firmware-builds/', { params: { is_active: true, page_size: 100 } })
      .then((d) => setBuilds(listOf(d)))
      .catch(() => {})
  }, [fc.id])
  useEffect(() => { load() }, [load])

  const flashBuild = async (e) => {
    e.preventDefault(); setBusy(true); setError('')
    try {
      await api('/api/firmware-builds/flash/', {
        method: 'POST',
        body: {
          fc: fc.id, build: Number(selectedBuild),
          stage_record: current?.id ?? null,
          flashing_result: flashResult, config_result: flashResult,
          notes: flashNotes,
        },
      })
      setSelectedBuild(''); setFlashNotes(''); load(); onDone()
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  const set = (k) => (e) =>
    setForm((f) => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setError('')
    try {
      await api('/api/firmware-records/', {
        method: 'POST',
        body: {
          ...form, fc: fc.id, stage_record: current?.id ?? null,
          parameter_profile: form.parameter_profile ? Number(form.parameter_profile) : null,
        },
      })
      setForm((f) => ({ ...f, notes: '' }))
      load(); onDone()
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  return (
    <>
      <h3>Firmware history</h3>
      {rows.length === 0 ? <Empty>No firmware recorded yet.</Empty> : (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Firmware</th><th>Source</th><th>Signed</th><th>Bootloader</th>
              <th>Params</th><th>Flash</th><th>Operator</th><th>When</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td>{r.firmware_name} <span className="mono">{r.version}</span>
                    {r.is_current ? <> <Tag tone="info">current</Tag></> : null}</td>
                  <td className="small">{humanize(r.source_type)}</td>
                  <td className="small">{r.is_signed ? 'Signed' : 'Unsigned'}{r.is_locked ? ' · locked' : ''}</td>
                  <td className="small mono">{r.bootloader_version || '—'}</td>
                  <td className="small">{r.parameter_profile_label || '—'}</td>
                  <td><StatusTag value={r.flashing_result === 'SUCCESS' ? 'PASSED' : 'FAILED'} /></td>
                  <td className="small">{r.operator_name}</td>
                  <td className="small muted">{when(r.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div style={{ marginTop: 18, borderTop: '1px solid var(--border)', paddingTop: 14 }}>
        <h3>Flash a build from the catalogue</h3>
        <Banner>{error}</Banner>
        <p className="small muted" style={{ marginTop: 0 }}>
          The build's details are copied onto this FC's record, so its history
          stays accurate even if the catalogue entry changes later.
        </p>
        <form onSubmit={flashBuild}>
          <div className="grid cols-3">
            <Field label="Firmware build">
              <select value={selectedBuild} onChange={(e) => setSelectedBuild(e.target.value)}>
                <option value="">— select a build —</option>
                {builds.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} {b.version} · {b.firmware_type}
                    {b.is_signed ? ' · signed' : ''}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Flashing result">
              <select value={flashResult} onChange={(e) => setFlashResult(e.target.value)}>
                <option value="SUCCESS">Success</option>
                <option value="PARTIAL">Partial</option>
                <option value="FAILED">Failed</option>
              </select>
            </Field>
            <Field label="Notes">
              <input value={flashNotes} onChange={(e) => setFlashNotes(e.target.value)} />
            </Field>
          </div>
          <div className="row">
            <button disabled={busy || !selectedBuild}>Record flash</button>
            <button type="button" className="secondary" onClick={() => setManual((m) => !m)}>
              {manual ? 'Hide manual entry' : 'Enter manually instead'}
            </button>
          </div>
          {builds.length === 0 ? (
            <p className="small muted">
              No active firmware builds in the catalogue yet — the Firmware
              department adds them under Manage Firmware.
            </p>
          ) : null}
        </form>
      </div>

      <form onSubmit={submit} hidden={!manual}
            style={{ marginTop: 18, borderTop: '1px solid var(--border)', paddingTop: 14 }}>
        <h3>Record a firmware operation manually</h3>
        <div className="grid cols-3">
          <Field label="Firmware name"><input value={form.firmware_name} onChange={set('firmware_name')} required /></Field>
          <Field label="Version"><input value={form.version} onChange={set('version')} required /></Field>
          <Field label="Source">
            <select value={form.source_type} onChange={set('source_type')}>
              <option value="OPEN_SOURCE">Open source</option>
              <option value="CLOSED_SOURCE">Closed source</option>
            </select>
          </Field>
          <Field label="Bootloader version"><input value={form.bootloader_version} onChange={set('bootloader_version')} /></Field>
          <Field label="Build / git ref"><input value={form.build_ref} onChange={set('build_ref')} /></Field>
          <Field label="Parameter profile">
            <select value={form.parameter_profile} onChange={set('parameter_profile')}>
              <option value="">— none —</option>
              {profiles.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
            </select>
          </Field>
          <Field label="Script name"><input value={form.script_name} onChange={set('script_name')} /></Field>
          <Field label="Script version"><input value={form.script_version} onChange={set('script_version')} /></Field>
          <Field label="Flashing result">
            <select value={form.flashing_result} onChange={set('flashing_result')}>
              <option value="SUCCESS">Success</option><option value="PARTIAL">Partial</option>
              <option value="FAILED">Failed</option>
            </select>
          </Field>
          <Field label="Configuration result">
            <select value={form.config_result} onChange={set('config_result')}>
              <option value="SUCCESS">Success</option><option value="PARTIAL">Partial</option>
              <option value="FAILED">Failed</option>
            </select>
          </Field>
        </div>
        <div className="row" style={{ marginBottom: 10 }}>
          <label className="row small" style={{ marginBottom: 0 }}>
            <input type="checkbox" checked={form.is_signed} onChange={set('is_signed')}
                   style={{ width: 'auto' }} /> Signed
          </label>
          <label className="row small" style={{ marginBottom: 0 }}>
            <input type="checkbox" checked={form.is_locked} onChange={set('is_locked')}
                   style={{ width: 'auto' }} /> Locked
          </label>
        </div>
        <Field label="Notes"><textarea value={form.notes} onChange={set('notes')} /></Field>
        <button disabled={busy}>Save firmware record</button>
      </form>
    </>
  )
}

function TestTab({ fc, current, onDone }) {
  const [templates, setTemplates] = useState([])
  const [versions, setVersions] = useState([])
  const [rows, setRows] = useState([])
  const [items, setItems] = useState([])
  const [gcs, setGcs] = useState('')
  const [cfg, setCfg] = useState('')
  const [notes, setNotes] = useState('')
  const [version, setVersion] = useState(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const stage = fc.current_stage

  const load = useCallback(() => {
    api('/api/test-results/', { params: { fc: fc.id } }).then((d) => setRows(listOf(d)))
  }, [fc.id])

  useEffect(() => {
    load()
    api('/api/software-versions/', { params: { page_size: 100 } }).then((d) => setVersions(listOf(d)))
    // Pull the checklist through /current/ so the tester always sees exactly the
    // configuration a manager has published, together with its version.
    api('/api/checklist-templates/', { params: { stage, is_active: true } })
      .then((d) => {
        const list = listOf(d)
        setTemplates(list)
        if (!list[0]) { setItems([]); return }
        return api(`/api/checklist-templates/${list[0].id}/current/`).then((cfg) => {
          setVersion(cfg.version)
          setItems((cfg.items || []).map((i) => ({ ...i, passed: true, note: '' })))
        })
      })
      .catch(() => {})
  }, [stage, load])

  if (!TEST_STAGES.includes(stage)) {
    return (
      <>
        <h3>Test results</h3>
        <p className="muted small">
          The FC is at {humanize(stage)}, which is not a testing stage. Existing results:
        </p>
        <ResultsTable rows={rows} />
      </>
    )
  }

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setError('')
    try {
      await api('/api/test-results/', {
        method: 'POST',
        body: {
          fc: fc.id, stage_record: current?.id, test_type: stage,
          template: templates[0]?.id ?? null, checklist_results: items,
          gcs_version: gcs ? Number(gcs) : null,
          configurator_version: cfg ? Number(cfg) : null, notes,
        },
      })
      setNotes(''); load(); onDone()
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  return (
    <>
      <h3>Test results</h3>
      <ResultsTable rows={rows} />
      <form onSubmit={submit} style={{ marginTop: 18, borderTop: '1px solid var(--border)', paddingTop: 14 }}>
        <h3>
          Record {humanize(stage)} checklist
          {version ? <span className="tag info" style={{ marginLeft: 8 }}>
            checklist v{version}</span> : null}
        </h3>
        <Banner>{error}</Banner>
        {items.length === 0 ? <Empty>No checklist template configured for this stage.</Empty> : null}
        {items.map((item, idx) => (
          <div key={item.key} className="row" style={{ marginBottom: 6 }}>
            <input type="checkbox" checked={item.passed} style={{ width: 'auto' }}
                   onChange={(e) => setItems((all) =>
                     all.map((x, i) => (i === idx ? { ...x, passed: e.target.checked } : x)))} />
            <span style={{ minWidth: 260 }}>
              {item.label}
              {item.mandatory === false
                ? <span className="muted small"> (optional)</span> : null}
              {item.description
                ? <div className="small muted">{item.description}</div> : null}
            </span>
            <input placeholder="Note (optional)" value={item.note} style={{ maxWidth: 320 }}
                   onChange={(e) => setItems((all) =>
                     all.map((x, i) => (i === idx ? { ...x, note: e.target.value } : x)))} />
          </div>
        ))}
        <div className="grid cols-2" style={{ marginTop: 12 }}>
          <Field label="GCS version used">
            <select value={gcs} onChange={(e) => setGcs(e.target.value)}>
              <option value="">— not recorded —</option>
              {versions.filter((v) => v.kind === 'GCS').map((v) => (
                <option key={v.id} value={v.id}>{v.version}</option>))}
            </select>
          </Field>
          <Field label="Configurator version used">
            <select value={cfg} onChange={(e) => setCfg(e.target.value)}>
              <option value="">— not recorded —</option>
              {versions.filter((v) => v.kind === 'CONFIGURATOR').map((v) => (
                <option key={v.id} value={v.id}>{v.version}</option>))}
            </select>
          </Field>
        </div>
        <Field label="Notes"><textarea value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
        <button disabled={busy || items.length === 0}>Save test result</button>
      </form>
    </>
  )
}

function ResultsTable({ rows }) {
  if (!rows.length) return <Empty>No test results recorded.</Empty>
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Test</th><th>Result</th><th>Failed items</th><th>GCS</th>
          <th>Configurator</th><th>Tester</th><th>When</th></tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>{humanize(r.test_type)}</td>
              <td><StatusTag value={r.overall_passed ? 'PASSED' : 'FAILED'} /></td>
              <td className="small">
                {(r.checklist_results || []).filter((i) => !i.passed)
                  .map((i) => i.label).join(', ') || '—'}
              </td>
              <td className="small mono">{r.gcs_version_label || '—'}</td>
              <td className="small mono">{r.configurator_version_label || '—'}</td>
              <td className="small">{r.tester_name}</td>
              <td className="small muted">{when(r.created_at)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function AuditTable({ rows }) {
  if (!rows.length) return <Empty>No audit entries.</Empty>
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>When</th><th>Action</th><th>Entity</th><th>Actor</th><th>Change</th></tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td className="small muted">{when(r.created_at)}</td>
              <td className="small">{humanize(r.action)}</td>
              <td className="small">{r.entity_type} · {r.entity_label}</td>
              <td className="small">{r.actor_name}</td>
              <td className="small mono" style={{ maxWidth: 380, wordBreak: 'break-word' }}>
                {r.note ? <div>{r.note}</div> : null}
                {r.after ? <div className="muted">{JSON.stringify(r.after).slice(0, 220)}</div> : null}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}


function FailPanel({ fc, busy, notes, onSubmit }) {
  const [target, setTarget] = useState('')
  const [reason, setReason] = useState('')
  const options = fc.return_options || []
  const chosen = options.find((o) => o.value === target)
  const exceptional = Boolean(target) && chosen && !chosen.standard

  return (
    <div style={{ marginTop: 12, borderTop: '1px solid var(--border)', paddingTop: 12 }}>
      <h3 style={{ marginTop: 0 }}>Which stage is responsible?</h3>
      <p className="small muted" style={{ marginTop: 0 }}>
        A fault found here may have originated earlier. Naming that stage sends
        the FC back to it, and the lifecycle continues from there — the failed
        attempt stays in the record either way.
      </p>
      <Field label="Return the FC to">
        <select value={target} onChange={(e) => setTarget(e.target.value)}>
          <option value="">— stay here, just record the failure —</option>
          <optgroup label="Usual routes">
            {options.filter((o) => o.standard).map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </optgroup>
          <optgroup label="Other earlier stages (recorded as exceptional)">
            {options.filter((o) => !o.standard).map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </optgroup>
        </select>
      </Field>
      {exceptional ? (
        <div className="banner warn">
          {chosen.label} is not a usual route after a {fc.stage_progress?.find(
            (s) => s.stage === fc.current_stage)?.label} failure. Explain why that
          stage is responsible — this is recorded as an exceptional route.
        </div>
      ) : null}
      {target ? (
        <Field label={exceptional ? 'Why is that stage responsible? (required)'
                                  : 'What needs reworking there?'}>
          <textarea value={reason} onChange={(e) => setReason(e.target.value)} />
        </Field>
      ) : null}
      <button className="danger"
              disabled={busy || (exceptional && !reason.trim())}
              onClick={() => onSubmit({
                return_to_stage: target || null,
                return_reason: reason,
              })}>
        {target ? `Fail and return to ${chosen?.label}` : 'Record the failure'}
      </button>
    </div>
  )
}
